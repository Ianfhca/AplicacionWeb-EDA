package fase3;

/**
 * Clase auxiliar para guardar una palabra y un nodo.
 * 
 * @author Ian Fernandez e Iker Go�i
 * 
 */
public class ResultadoMin {
	Palabra valor;
	NodoABBPalabras nodo;
}
