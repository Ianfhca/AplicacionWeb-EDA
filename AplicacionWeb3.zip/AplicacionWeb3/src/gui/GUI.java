package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import fase3.ABBPalabras;
import fase3.Diccionario;
import fase3.HashMapPalabras;
import fase3.Internet;
import fase3.ListaPalabras;
import fase3.ListaWebs;

/**
 * Genera una interfaz gr�fica del buscador web.
 * 
 * @author Ian Fernandez e Iker Go�i
 *
 */
public class GUI implements ActionListener {

	ImageIcon img = new ImageIcon("src/gui/Ruby.png");
	private JFrame frame;
	private JPanel panel, top, mid, bottom;

	private JTextField browser;
	private TextPrompt placeholder;

	private JButton search;

	private DefaultListModel<String> dlm;
	private JList<String> webList;

	private JLabel partners;

	private int selectUI;
	private int selectD;

	/**
	 * Constructora de GUI.
	 * 
	 * @param miInternet
	 */
	public GUI() throws IOException {

		selectUI = JOptionPane.showOptionDialog(frame, "�Deseas abrir la interfaz gr�fica?", "Ruby",
				JOptionPane.YES_NO_OPTION,
//				   JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE, null, // null para icono por defecto.
				new Object[] { "Si", "No" }, // null para YES, NO y CANCEL
				"Si");

		if (selectUI == 0) {

			System.out.println("Has seleccionado la versi�n de interfaz gr�fica.");

			selectD = JOptionPane.showOptionDialog(frame, "�Que tipo de diccionario quieres crear?", "Ruby",
					JOptionPane.YES_NO_OPTION,
//					   JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, // null Para icono por defecto.
					new Object[] { "Lista", "ABB", "HashMap" }, // null Para YES, NO y CANCEL
					"Si");

			// Inizializar Internet
			Internet miInternet = Internet.getInstance();
			miInternet.inicializar("src/ficheros/smallindex", "src/ficheros/smallpld-arc");

			// Inizializar Diccionario
			Diccionario miDiccionario = Diccionario.getInstance();

			// Seleccionar Diccionario
			switch (selectD) {
			case 0:
				System.out.println("Creando una lista para el diccionario...");
				ListaPalabras wordList = new ListaPalabras();
				miDiccionario.setDiccionario(wordList);
				miDiccionario.inicializar("src/ficheros/wordsshuffle.txt");
				break;
			case 1:
				System.out.println("Creando un ABB para el diccionario...");
				ABBPalabras arbol = new ABBPalabras();
				miDiccionario.setDiccionario(arbol);
				miDiccionario.inicializar("src/ficheros/wordsshuffle.txt");
				System.out.println("Filtrando diccionario por palabras clave... ");
				arbol.filtrarPalabrasClave();
				break;
			case 2:
				System.out.println("Creando un HashMap para el diccionario...");
				HashMapPalabras hashMap = new HashMapPalabras();
				miDiccionario.setDiccionario(hashMap);
				miDiccionario.inicializar("src/ficheros/wordsshuffle.txt");
				break;
			default:
				System.out.println("Creando un HashMap para el diccionario...");
				HashMapPalabras hashMap2 = new HashMapPalabras();
				miDiccionario.setDiccionario(hashMap2);
				miDiccionario.inicializar("src/ficheros/wordsshuffle.txt");
				break;
			}

			System.out.println("Completado. \n");

			Font f1 = new Font(Font.SANS_SERIF, Font.BOLD, 13);

			frame = new JFrame();

			panel = new JPanel();
			top = new JPanel();
			mid = new JPanel();
			bottom = new JPanel();

			browser = new JTextField();
			placeholder = new TextPrompt("Buscar en Ruby o introducir URL", browser);
			placeholder.changeAlpha(0.75f);
			placeholder.changeStyle(Font.ITALIC);
			browser.setPreferredSize(new Dimension(300, 28));

			dlm = new DefaultListModel<String>();
			webList = new JList<String>(dlm);
			JScrollPane scroll = new JScrollPane(webList);
			scroll.setPreferredSize(new Dimension(375, 300));

			partners = new JLabel("Ian Fernandez e Iker Go�i");

			search = new JButton(new AbstractAction("Buscar") {

				private static final long serialVersionUID = 1L;

				@Override
				public void actionPerformed(ActionEvent e) {
					String text = browser.getText();
					ListaWebs lista = miInternet.buscadorWeb(text);
					webList.setFont(f1);
					dlm.removeAllElements();
					if (lista.getSize() > 0) {
						dlm.addElement(lista.getSize() + " resultados para '" + text + "'");
						for (int i = 0; i < lista.getSize(); i++) {
							dlm.addElement(" - " + lista.getWebList()[i].getDirection());
						}
					} else {
						dlm.addElement("Ninguna coincidencia para '" + text + "'.");
					}
					scroll.setVisible(true);
					webList.setVisible(true);
				}
			});

			panel.setLayout(new BorderLayout(10, 10));
//			panel.setPreferredSize(new Dimension(840, 480));
			panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
			panel.add(top, BorderLayout.NORTH);
			panel.add(mid, BorderLayout.CENTER);
			panel.add(bottom, BorderLayout.SOUTH);

			top.add(browser);
			top.add(search);
			search.requestFocus();
			mid.add(scroll);
			bottom.add(partners);

			frame.add(panel);
			frame.pack();
			frame.setLocationRelativeTo(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setLayout(new FlowLayout());
			frame.setMinimumSize(new Dimension(500, 500));
			frame.setTitle("Ruby");
			frame.setIconImage(img.getImage());
			frame.setVisible(true);
			frame.getRootPane().setDefaultButton(search);
		} else if (selectUI == 1) {
			System.out.println("    �Bienvenido al buscador Ruby!\n");

			System.out.println("                #/\\#");
			System.out.println("              ##//\\\\\\#");
			System.out.println("            ##//#####\\\\\\#");
			System.out.println("          ##//########\\\\\\#");
			System.out.println("        ##//############\\\\\\#");
			System.out.println("       ##//##############\\\\##");
			System.out.println("      ##||################||##");
			System.out.println("      #&||################||##");
			System.out.println("      &&||################||#&");
			System.out.println("      &&||################||&&");
			System.out.println("       &&\\\\##############//&&");
			System.out.println("        &&\\\\############//#&");
			System.out.println("          &&\\\\########//#&");
			System.out.println("            &&\\\\#####//##");
			System.out.println("               &\\\\//#");
			System.out.println("                &\\/#");
			System.out.println();

			System.out.println("      Ian Fernandez e Iker Go�i\n");

			System.out.println("Has elegido la versi�n de consola.");
		} else {
			System.exit(0);
		}
	}

	/**
	 * Devuelve la selecci�n del usuario 0- Usar la interfaz gr�fica 1- Usar la
	 * consola (-1)- Cerrar el programa
	 * 
	 * @return Un numero entero que representa la selecci�n del usuario
	 */
	public int getSelection() {
		return this.selectUI;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// No realiza ninguna acci�n
	}

}
